public class Main {
    public static void main(String[] args) {
        run();
    }
    public static void run() {
        EchoServer.bindToPort(8788).run();
    }
}