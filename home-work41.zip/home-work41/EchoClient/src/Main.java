public class Main {
    public static void main(String[] args) {
        run();
    }
    public static void run() {
        EchoClient.connectTo(8788).run();
    }
}